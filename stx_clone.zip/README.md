# stx_study
